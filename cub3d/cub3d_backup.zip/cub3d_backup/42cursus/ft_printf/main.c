#include "ft_printf.h"
#include <stdio.h>

int main()
{
	int		a = -4;
	int		b = 0;
	char	c = 'a';
	int		d = 2147483647;
	int		e = -2147483648;
	int		f = 42;
	int		g = 25;
	int		h = 4200;
	int		i = 8;
	int		j = -12;
	int		k = 123456789;
	int		l = 0;
	int		m = -12345678;
	int		ret;


	// printf("----------------ft_printf---------------\n");
	// ret = ft_printf("This is: %.*i, %.*d, %.*d, %.*d, %.*d, %.*d, %.*d, %.*d", a, i, a, j, a, k, a, l, a, m, a, c, a, e, a, d);
	// printf("return : %d\n", ret);

	// printf("\n\n\n------------------printf---------------\n");
	// ret = printf("this is %2147483646d", 42);
	// printf("%d\n", ret);

	// ret = printf("This is: %.*i, %.*d, %.*d, %.*d, %.*d, %.*d, %.*d, %.*d", a, i, a, j, a, k, a, l, a, m, a, c, a, e, a, d);


	a = ft_printf("val : |%2147483698d|\n", 42);
	printf("ret : %d\n", a);
	a = printf("val : |%2147483699d|\n", 42);
	printf("ret : %d\n", a);



	// printf("ret : %d\n", ft_printf("%c, %-c, %12c, %-3c, %-1c, %1c, %-2c, %-4c, %5c, %3c, %-*c, %-*c, %*c, %*c\n\n", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0,     0, 0));
	// printf("ret : %d\n", printf("%c, %-c, %12c, %-3c, %-1c, %1c, %-2c, %-4c, %5c, %3c, %-*c, %-*c, %*c, %*c\n\n", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0,     0, 0));
	// printf("return : %d\n", ret);
}
