gcc *.c libft.a
./a.out

rm ./a.out