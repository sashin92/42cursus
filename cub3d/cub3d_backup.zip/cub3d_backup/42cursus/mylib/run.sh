#!/bin/bash

make
make clean