Libft
=====

 Test libft codes using below listed program
 -------------------------------------------

	git clone https://github.com/jtoty/Libftest.git

	git clone https://github.com/alelievr/libft-unit-test.git

	git clone https://github.com/ska42/libft-war-machine.git
