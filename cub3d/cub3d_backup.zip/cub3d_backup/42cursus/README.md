# 42cursus
subject in 42seoul
